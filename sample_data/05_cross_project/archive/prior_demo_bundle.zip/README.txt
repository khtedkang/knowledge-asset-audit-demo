Synthetic archive retained only to exercise asset-type classification.
